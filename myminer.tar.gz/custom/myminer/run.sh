#!/bin/bash

./myminer --algo OCTOPUS --pool $CUSTOM_URL --user --wallet $CUSTOM_TEMPLATE >> myminer.log 2>&1