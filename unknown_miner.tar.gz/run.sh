#!/bin/bash

./unknown_miner --algo OCTOPUS --pool $CUSTOM_URL --user --wallet $CUSTOM_TEMPLATE >> myminer.log 2>&1